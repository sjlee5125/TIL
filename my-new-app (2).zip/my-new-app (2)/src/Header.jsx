import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Header() {
  const navigate = useNavigate();
  const [showStickyTitle, setShowStickyTitle] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);

  // 스크롤에 따른 sticky 제목 처리
  const handleScroll = () => {
    setShowStickyTitle(window.scrollY > 100);
  };

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // 검색어에 따른 자동완성 (검색어가 비어있으면 suggestions 비움)
  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (searchQuery.trim() !== "") {
        fetch(
          `http://localhost:8080/university/search?keyword=${encodeURIComponent(
            searchQuery
          )}`
        )
          .then((response) => response.json())
          .then((data) => {
            setSuggestions(data);
          })
          .catch((error) =>
            console.error("Error fetching suggestions:", error)
          );
      } else {
        setSuggestions([]);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  // 검색 버튼 클릭 또는 엔터키 입력
  const handleSearch = () => {
    if (searchQuery.trim() === "") {
      alert("학교를 입력해주세요!");
      return;
    }

    fetch(
      `http://localhost:8080/university/search?keyword=${encodeURIComponent(
        searchQuery
      )}`
    )
      .then((response) => response.json())
      .then((data) => {
        if (data && data.length > 0) {
          const foundUniversity = data[0];
          navigate(`/school/${foundUniversity.id}`);
        } else {
          alert("검색한 학교가 없습니다.");
        }
      })
      .catch((err) => {
        console.error("검색 중 에러 발생:", err);
        alert("검색 중 에러가 발생했습니다.");
      });
  };

  return (
    <>
      {/* 최상단 메뉴 영역 */}
      <div
        style={{
          background: "#ffffff",
          borderBottom: "1px solid #e0e0e0",
          padding: "10px 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginTop: "-40px",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            fontSize: "20px",
            fontWeight: "bold",
          }}
        >
          <span
            onClick={() => window.location.href="http://localhost:5173/"}
            style={{
              cursor: "pointer",
              marginRight: "30px",
              fontSize: "30px",
            }}
          >
            학교랭킹
          </span>
          <span
            onClick={() => navigate("/ranking")}
            style={{
              cursor: "pointer",
              fontWeight: "normal",
              marginRight: "30px",
            }}
          >
            캠퍼스 랭킹
          </span>
          <span
            onClick={() => navigate("/news")}
            style={{
              cursor: "pointer",
              fontWeight: "normal",
              marginRight: "30px",
            }}
          >
            뉴스
          </span>
          <span
            onClick={() => navigate("/location")}
            style={{ cursor: "pointer", fontWeight: "normal" }}
          >
            캠퍼스 위치
          </span>
        </div>
        <div style={{ fontSize: "20px" }}>
          <span
            onClick={() => navigate("/login")}
            style={{ cursor: "pointer" }}
          >
            로그인
          </span>
          <span> | </span>
          <span
            onClick={() => navigate("/signup")}
            style={{ cursor: "pointer" }}
          >
            회원가입
          </span>
        </div>
      </div>

      {/* Sticky 검색 영역 */}
      <div
        style={{
          position: "sticky",
          top: 0,
          zIndex: 9,
          background: "#ffffff",
          padding: "20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          borderBottom: "1px solid #ccc",
        }}
      >
        {showStickyTitle && (
          <div
            style={{
              color: "black",
              textAlign: "left",
              fontSize: "30px",
              fontWeight: "bold",
              background: "#ffffff",
              marginRight: "30px",
            }}
          >
            <span
              onClick={() => window.location.reload()}
              style={{ cursor: "pointer" }}
            >
              학교랭킹
            </span>
          </div>
        )}
        <div style={{ position: "relative", width: "80%", maxWidth: "1000px" }}>
          <input
            id="searchInput"
            style={{
              width: "100%",
              padding: "15px",
              fontSize: "16px",
              border: "1px solid rgb(248, 194, 127)",
              borderRadius: "5px",
            }}
            type="text"
            placeholder="학교를 검색해보세요."
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                handleSearch();
              }
            }}
            onFocus={(event) => {
              event.target.style.borderColor = "rgb(248,194,127)";
              event.target.style.outline = "none";
            }}
          />
          {suggestions.length > 0 && (
            <div
              style={{
                position: "absolute",
                top: "100%",
                left: 0,
                width: "100%",
                background: "#fff",
                boxShadow: "0 2px 4px rgba(0,0,0,0.15)",
                zIndex: 10,
              }}
            >
              {suggestions.map((school, index) => (
                <div
                  key={index}
                  onClick={() => navigate(`/school/${school.id}`)}
                  style={{
                    padding: "10px",
                    cursor: "pointer",
                    borderBottom: "1px solid #eee",
                  }}
                >
                  {school.name}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default Header;
