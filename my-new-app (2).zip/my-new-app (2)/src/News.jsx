import React from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css';

function News() {
    const navigate = useNavigate();

    const announcements = [
        {
            id: 1,
            title: "신구",
            content: "Shingu",
            image: "https://i.namu.wiki/i/MvxviED-As23tzAx7u-5niU47UqzpdECHeahRWGJ1GdQCnbi77Jqn3Qxvtl6Wb-TTs73rXtcKQlRhfvWmCQ4NxffHLxCM2M4EcAC07vlkSG3e6a46z_rLeWbw2Q6ofGZF6_JwW-xB25dyke0ZTEpaA.svg"
        },
        {
            id: 2,
            title: "참치앤김치",
            content: "참치에는 와인!",
            image: "https://flexible.img.hani.co.kr/flexible/normal/900/675/imgdb/original/2021/0825/20210825503877.jpg"
        },
        {
            id: 3,
            title: "오늘의 교보문고",
            content: "BEST 추천 책",
            image: "https://contents.kyobobook.co.kr/sih/fit-in/458x0/pdt/9791191114768.jpg"
        },
    ];

    const handleAnnouncementClick = (announcement) => {
        navigate(`/announcement/${announcement.id}`, { state: announcement });
    };

    return (
        <>
            {/* 공지사항 목록 */}
            <div style={{ textAlign: "center", marginTop: "60px" }}>
                <h1 style={{ fontSize: "40px", fontWeight: "bold", color: "#333" }}>뉴스</h1>
                <p style={{ fontSize: "18px", color: "#666" }}>아래 뉴스를 클릭하여 자세한 내용을 확인하세요.</p>
            </div>
            
            <div style={{
                display: "flex",
                flexWrap: "wrap",
                justifyContent: "center",
                gap: "20px",
                padding: "20px",
            }}>
                {announcements.map((announcement) => (
                    <div
                        key={announcement.id}
                        style={{
                            width: "300px",
                            border: "1px solid #ddd",
                            borderRadius: "10px",
                            overflow: "hidden",
                            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
                            cursor: "pointer",
                            backgroundColor: "#fff",
                            transition: "transform 0.3s, box-shadow 0.3s",
                        }}
                        onClick={() => handleAnnouncementClick(announcement)}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.transform = "scale(1.05)";
                            e.currentTarget.style.boxShadow = "0 6px 10px rgba(0, 0, 0, 0.15)";
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.transform = "scale(1)";
                            e.currentTarget.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
                        }}
                    >
                        <img
                            src={announcement.image}
                            alt={announcement.title}
                            style={{
                                width: "100%",
                                height: "200px",
                                objectFit: "cover",
                                borderBottom: "1px solid #ddd",
                            }}
                        />
                        <div style={{ padding: "15px" }}>
                            <h3 style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "10px" }}>
                                {announcement.title}
                            </h3>
                            <p style={{ fontSize: "14px", color: "#777" }}>
                                {announcement.content.length > 30
                                    ? announcement.content.substring(0, 30) + "..."
                                    : announcement.content}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </>
    );
}
export default News;