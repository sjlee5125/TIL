import reactLogo from './assets/react.svg';
import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import viteLogo from '/vite.svg';
import './App.css';
import './Home.jsx';

function Ranking() {
  const navigate = useNavigate();

  const [rankings, setRankings] = useState({
    professor: [],
    career: [],
    education: [],
    campus: [],
    club: [],
    satisfaction: [],
  });

  useEffect(() => {
    fetch('http://localhost:8080/university/rankings/all')
      .then((res) => res.json())
      .then((data) => {
        const sortedData = {};
        Object.keys(data).forEach((key) => {
          sortedData[key] = data[key].sort((a, b) => b.averageScore - a.averageScore);
        });
        setRankings(sortedData);
      })
      .catch((err) => {
        console.error('데이터 불러오기 실패:', err);
      });
  }, []);

  const categories = [
    { key: "professor", title: "항목 A" },
    { key: "career", title: "항목 B" },
    { key: "education", title: "항목 C" },
    { key: "campus", title: "항목 D" },
    { key: "club", title: "항목 E" },
    { key: "satisfaction", title: "항목 F" },
  ];

  const renderScoreBlocks = (score) => {
    const blocks = [];
    const blockCount = 5;
    const blockValue = 1.0;

    for (let i = 0; i < blockCount; i++) {
      let fillRatio = Math.min(Math.max(score - i * blockValue, 0), blockValue);
      blocks.push(
        <div
          key={i}
          style={{
            width: '30px',
            height: '8px',
            marginRight: '4px',
            background: `linear-gradient(to right, #5a6771 ${fillRatio * 100}%, #d3d3d3 ${fillRatio * 100}%)`,
            display: 'inline-block',
            borderRadius: '2px'
          }}
        />
      );
    }
    return blocks;
  };

  return (
    <div style={{ paddingBottom: '100px' }}>
      <div style={{
        fontSize: "25px",
        paddingTop: "50px",
        fontWeight: "bold",
        textAlign: "center"
      }}>
        캠퍼스랭킹
      </div>

      <div style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        marginTop: "40px",
        gap: "20px",
        maxWidth: "1100px",
        marginLeft: "auto",
        marginRight: "auto"
      }}>
        {categories.map((cat) => (
          <div key={cat.key} style={{
            width: "300px",
            border: "0.5px solid rgb(191,191,191)",
            padding: "20px",
          }}>
            <h2 style={{
              fontSize: "17px",
              fontWeight: "bold",
              marginBottom: "20px",
              textAlign: "left"
            }}>{cat.title}</h2>

            {rankings[cat.key]?.slice(0, 5).map((item, index) => (
              <div key={item.universityId} style={{ marginBottom: "16px" }}>
                <div style={{ fontSize: "13px", marginBottom: "4px" }}>
                  {index + 1}위 {item.universityName}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <div style={{ display: 'flex' }}>
                    {renderScoreBlocks(item.averageScore)}
                  </div>
                  <div style={{ fontSize: '13px', marginLeft: '8px' }}>{item.averageScore.toFixed(2)}</div>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Ranking;