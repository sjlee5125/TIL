function EuljiPage() {
    return (
      <div style={{ padding: '20px' }}>
        <h1>을지대학교</h1>
        <p>을지대학교에 대한 상세 설명 페이지입니다.</p>
      </div>
    );
  }
  
  export default EuljiPage;