import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';

function Header() {
    const navigate = useNavigate();
    const [showStickyTitle, setShowStickyTitle] = useState(false);

    const handleScroll = () => {
        // 스크롤 위치가 특정 값 이상이면 sticky 제목을 보여주고, 아니면 숨깁니다.
        // 스크롤 값 100은 예시이며, 실제 레이아웃에 맞춰 조정해야 합니다.
        if (window.scrollY > 100) {
            setShowStickyTitle(true);
        } else {
            setShowStickyTitle(false);
        }
    };

    useEffect(() => {
        // 컴포넌트가 마운트될 때 스크롤 이벤트 리스너를 추가합니다.
        window.addEventListener('scroll', handleScroll);

        // 컴포넌트가 언마운트될 때 이벤트 리스너를 제거하여 메모리 누수를 방지합니다.
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []); // 빈 dependency 배열은 컴포넌트가 처음 마운트될 때만 실행되도록 합니다.

    const handleSearch = () => {
        const searchQuery = document.getElementById("searchInput").value;
        if (searchQuery) {
            navigate(`/search?query=${searchQuery}`);
        } else {
            alert("학교를 입력해주세요!");
        }
    };

    return (
        <>
            {/* 최상단 메뉴 영역 (스크롤되지 않음) */}
            <div style={{
                background: "#ffffff",
                borderBottom: "1px solid #e0e0e0",
                padding: "10px 20px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginTop: "-40px"
            }}>
                <div style={{ display: "flex", alignItems: "center", fontSize: "20px", fontWeight: "bold" }}>
                    <span onClick={() => navigate("/")} style={{ cursor: "pointer", marginRight: "30px", fontSize: "30px" }}>학교랭킹</span>
                    <span onClick={() => navigate("/ranking")} style={{ cursor: "pointer", fontWeight: "normal" }}
                        onMouseEnter={(e) => { e.currentTarget.style.color = "rgb(248, 194, 127)"; e.currentTarget.style.fontWeight = "bold"; }}
                        onMouseLeave={(e) => { e.currentTarget.style.color = "#000000"; e.currentTarget.style.fontWeight = "normal"; }}>캠퍼스 랭킹</span>
                    <span onClick={() => navigate("/news")} style={{ cursor: "pointer", fontWeight: "normal", marginLeft: "30px" }}
                        onMouseEnter={(e) => { e.currentTarget.style.color = "rgb(248, 194, 127)"; e.currentTarget.style.fontWeight = "bold"; }}
                        onMouseLeave={(e) => { e.currentTarget.style.color = "#000000"; e.currentTarget.style.fontWeight = "normal"; }}>뉴스</span>
                    <span onClick={() => navigate("location")} style={{ cursor: "pointer", fontWeight: "normal", marginLeft: "30px" }}
                        onMouseEnter={(e) => { e.currentTarget.style.color = "rgb(248, 194, 127)"; e.currentTarget.style.fontWeight = "bold"; }}
                        onMouseLeave={(e) => { e.currentTarget.style.color = "#000000"; e.currentTarget.style.fontWeight = "normal"; }}>캠퍼스 위치</span>
                </div>
                <div style={{ fontSize: "20px" }}>
                    <span onClick={() => navigate("/login")} style={{ cursor: "pointer" }}>로그인</span>
                    <span> | </span>
                    <span onClick={() => navigate("/signup")} style={{ cursor: "pointer" }}>회원가입</span>
                </div>
            </div>

            {/* Sticky 검색 영역 (학교랭킹 조건부 렌더링) */}
            <div style={{
                position: "sticky",
                top: 0,
                zIndex: 9,
                background: "#ffffff",
                padding: "20px",
                display: "flex",
                alignItems: "center", /* 세로 중앙 정렬 */
                justifyContent: "center",
                borderBottom: "1px solid #ccc",
                
            }}>
                {showStickyTitle && (
                    <div
                        style={{
                            color: "black",
                            textAlign: "left",
                            fontSize: "30px",
                            fontWeight: "bold",
                            background: "#ffffff",
                            marginRight: "30px", /* 검색창과의 간격 조절 */
                        }}
                    >
                        <span onClick={() => navigate("/")} style={{ cursor: "pointer" }}>학교랭킹</span>
                    </div>
                )}
                <input
                    id="searchInput"
                    style={{
                        width: "80%",
                        maxWidth: "1000px",
                        padding: "15px",
                        fontSize: "16px",
                        border: "1px solid rgb(248, 194, 127)",
                        borderRadius: "5px",
                    }}
                    type="text"
                    placeholder="학교를 검색해보세요."
                    onKeyDown={(event) => {
                        if (event.key === "Enter") {
                            handleSearch();
                        }
                    }}
                    onFocus={(event) => {
                        event.target.style.borderColor = "rgb(248,194,127)"; 
                        event.target.style.outline = "none"; 
                      }}
                />
            </div>
        </>
    );
}

export default Header;